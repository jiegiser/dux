<?php
// Require theme functions
require get_stylesheet_directory() . '/functions-theme.php';

// Customize your functions

//由日了狗www.rledog.com分享
